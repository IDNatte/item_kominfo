function egovInfrastruktur() {
  var url = './data/egov_infra/data.pdf';

  var pdfjsLib = window['pdfjs-dist/build/pdf'];
  
  pdfjsLib.GlobalWorkerOptions.workerSrc = './assets/js/pdf.worker.js';
  
  var pdfDoc = null,
      pageNum = 1,
      pageRendering = false,
      pageNumPending = null,
      scale = 1.0,
      canvas = document.getElementById('data1-egovinf'),
      ctx = canvas.getContext('2d');
  
  function renderPage(num) {
    pageRendering = true;
    pdfDoc.getPage(num).then(function(page) {
      var viewport = page.getViewport({scale: scale});
      canvas.height = viewport.height;
      canvas.width = viewport.width;

      var renderContext = {
        canvasContext: ctx,
        viewport: viewport
      };
      var renderTask = page.render(renderContext);
  
      renderTask.promise.then(function() {
        pageRendering = false;
        if (pageNumPending !== null) {
          renderPage(pageNumPending);
          pageNumPending = null;
        }
      });
    });

    document.getElementById('page_num-egov').textContent = num;
  }
  
  function queueRenderPage(num) {
    if (pageRendering) {
      pageNumPending = num;
    } else {
      renderPage(num);
    }
  }
  
  function onPrevPage() {
    if (pageNum <= 1) {
      return;
    }
    pageNum--;
    queueRenderPage(pageNum);
  }
  document.getElementById('prev-egov').addEventListener('click', onPrevPage);
  
  function onNextPage() {
    if (pageNum >= pdfDoc.numPages) {
      return;
    }
    pageNum++;
    queueRenderPage(pageNum);
  }
  document.getElementById('next-egov').addEventListener('click', onNextPage);
  
  pdfjsLib.getDocument(url).promise.then(function(pdfDoc_) {
    pdfDoc = pdfDoc_;
    document.getElementById('page_count-egov').textContent = pdfDoc.numPages;
  
    renderPage(pageNum);
  }, function(reason) {
    if (reason.name === 'MissingPDFException') {
      $('#data-warning').append('<div class="alert alert-danger alert-dismissible fade show" role="alert">Data Tidak Ada<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>')
    }
  });
}

function iKP() {
  var url = './data/ikp/data.pdf';

  var pdfjsLib = window['pdfjs-dist/build/pdf'];
  
  pdfjsLib.GlobalWorkerOptions.workerSrc = './assets/js/pdf.worker.js';
  
  var pdfDoc = null,
      pageNum = 1,
      pageRendering = false,
      pageNumPending = null,
      scale = 1.0,
      canvas = document.getElementById('data1-ikp'),
      ctx = canvas.getContext('2d');
  
  function renderPage(num) {
    pageRendering = true;
    pdfDoc.getPage(num).then(function(page) {
      var viewport = page.getViewport({scale: scale});
      canvas.height = viewport.height;
      canvas.width = viewport.width;
  
      var renderContext = {
        canvasContext: ctx,
        viewport: viewport
      };
      var renderTask = page.render(renderContext);
  
      renderTask.promise.then(function() {
        pageRendering = false;
        if (pageNumPending !== null) {
          renderPage(pageNumPending);
          pageNumPending = null;
        }
      });
    });
  
    document.getElementById('page_num-ikp').textContent = num;
  }
  
  function queueRenderPage(num) {
    if (pageRendering) {
      pageNumPending = num;
    } else {
      renderPage(num);
    }
  }
  
  function onPrevPage() {
    if (pageNum <= 1) {
      return;
    }
    pageNum--;
    queueRenderPage(pageNum);
  }
  document.getElementById('prev-ikp').addEventListener('click', onPrevPage);
  
  function onNextPage() {
    if (pageNum >= pdfDoc.numPages) {
      return;
    }
    pageNum++;
    queueRenderPage(pageNum);
  }
  document.getElementById('next-ikp').addEventListener('click', onNextPage);
  
  pdfjsLib.getDocument(url).promise.then(function(pdfDoc_) {
    pdfDoc = pdfDoc_;
    document.getElementById('page_count-ikp').textContent = pdfDoc.numPages;
  
    renderPage(pageNum);
  }, function(reason) {
    if (reason.name === 'MissingPDFException') {
      $('#data-warning').append('<div class="alert alert-danger alert-dismissible fade show" role="alert">Data Tidak Ada<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>')
    }
  });
}

function persanTik() {
  var url = './data/sandi_statistik/data.pdf';

  var pdfjsLib = window['pdfjs-dist/build/pdf'];
  
  pdfjsLib.GlobalWorkerOptions.workerSrc = './assets/js/pdf.worker.js';
  
  var pdfDoc = null,
      pageNum = 1,
      pageRendering = false,
      pageNumPending = null,
      scale = 1.0,
      canvas = document.getElementById('data1-persanTik'),
      ctx = canvas.getContext('2d');
  
  function renderPage(num) {
    pageRendering = true;
    // Using promise to fetch the page
    pdfDoc.getPage(num).then(function(page) {
      var viewport = page.getViewport({scale: scale});
      canvas.height = viewport.height;
      canvas.width = viewport.width;
  
      // Render PDF page into canvas context
      var renderContext = {
        canvasContext: ctx,
        viewport: viewport
      };
      var renderTask = page.render(renderContext);
  
      // Wait for rendering to finish
      renderTask.promise.then(function() {
        pageRendering = false;
        if (pageNumPending !== null) {
          // New page rendering is pending
          renderPage(pageNumPending);
          pageNumPending = null;
        }
      });
    });
  
    // Update page counters
    document.getElementById('page_num-persanTik').textContent = num;
  }
  
  function queueRenderPage(num) {
    if (pageRendering) {
      pageNumPending = num;
    } else {
      renderPage(num);
    }
  }
  
  function onPrevPage() {
    if (pageNum <= 1) {
      return;
    }
    pageNum--;
    queueRenderPage(pageNum);
  }
  document.getElementById('prev-persanTik').addEventListener('click', onPrevPage);
  
  function onNextPage() {
    if (pageNum >= pdfDoc.numPages) {
      return;
    }
    pageNum++;
    queueRenderPage(pageNum);
  }
  document.getElementById('next-persanTik').addEventListener('click', onNextPage);
  
  pdfjsLib.getDocument(url).promise.then(function(pdfDoc_) {
    pdfDoc = pdfDoc_;
    document.getElementById('page_count-persanTik').textContent = pdfDoc.numPages;
  
    renderPage(pageNum);
  }, function(reason) {
    if (reason.name === 'MissingPDFException') {
      $('#data-warning').append('<div class="alert alert-danger alert-dismissible fade show" role="alert">Data Tidak Ada<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>')
    }
  });
}